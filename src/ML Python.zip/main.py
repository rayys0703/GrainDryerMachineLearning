import logging
import threading
from model import PredictionModel
from mqtt_service import MQTTService, run_flask

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    mqtt_service = None
    try:
        model = PredictionModel()
        logger.info("Prediction model initialized")

        mqtt_service = MQTTService(
            model=model,
            broker="broker.hivemq.com",
            port=1883,
            input_topic="iot/sensor/datagabah2",
            output_topic="iot/prediction/dryingtime",
            laravel_api_url="http://192.168.92.227:3333/api/prediction/receive",
            username="graindryer",
            password="polindra"
        )
        logger.info("MQTT service initialized")

        mqtt_thread = threading.Thread(target=mqtt_service.start_mqtt, daemon=True)
        mqtt_thread.start()
        logger.info("MQTT thread started")

        logger.info("Starting Flask server on http://127.0.0.1:5000")
        run_flask(mqtt_service)

    except KeyboardInterrupt:
        logger.info("Shutting down...")
        if mqtt_service:
            mqtt_service.stop()
    except Exception as e:
        logger.error(f"Error in main: {e}")
        if mqtt_service:
            mqtt_service.stop()

if __name__ == "__main__":
    main()