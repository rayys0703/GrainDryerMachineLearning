import paho.mqtt.client as mqtt
import json
import logging
import requests
import time
import threading
from flask import Flask, request, jsonify
from model import PredictionModel
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)

class MQTTService:
    def __init__(self, model, broker="broker.hivemq.com", port=1883, 
                 input_topic="iot/sensor/datagabah2", output_topic="iot/prediction/dryingtime",
                 laravel_api_url="http://192.168.92.227:3333/api/prediction/receive",
                 username="graindryer", password="polindra"):
        self.model = model
        self.broker = broker
        self.port = port
        self.input_topic = input_topic
        self.output_topic = output_topic
        self.laravel_api_url = laravel_api_url
        self.username = username
        self.password = password
        self.client = mqtt.Client()
        self.prediction_trigger = None
        self.lock = threading.Lock()

        # Setup HTTP session with retries
        self.session = requests.Session()
        retries = Retry(total=3, backoff_factor=0.5, status_forcelist=[500, 502, 503, 504])
        self.session.mount('http://', HTTPAdapter(max_retries=retries))

        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        if self.username and self.password:
            self.client.username_pw_set(self.username, self.password)

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            logger.info(f"Terhubung ke broker MQTT: {self.broker}:{self.port}")
            self.client.subscribe(self.input_topic, qos=0)
            logger.info(f"Berlangganan topik: {self.input_topic}")
        else:
            logger.error(f"Gagal terhubung ke broker: kode {rc}")
            raise Exception(f"Koneksi MQTT gagal: kode {rc}")

    def on_message(self, client, userdata, msg):
        try:
            with self.lock:
                if not self.prediction_trigger:
                    logger.info("Data sensor diabaikan: Tidak ada prediksi aktif")
                    return

                payload = json.loads(msg.payload.decode())
                if not (payload.get("points") and isinstance(payload["points"], list) and payload.get("room_temperature")):
                    logger.error("Format data sensor tidak valid")
                    return

                points = payload["points"]
                grain_temps = [p["grain_temperature"] for p in points if "grain_temperature" in p]
                grain_moists = [p["grain_moisture"] for p in points if "grain_moisture" in p]

                if not (grain_temps and grain_moists):
                    logger.error("Data suhu atau kadar air gabah tidak ada")
                    return

                avg_temp = round(sum(grain_temps) / len(grain_temps), 1)
                avg_moist = round(sum(grain_moists) / len(grain_moists), 1)
                room_temp = payload["room_temperature"]
                weight = self.prediction_trigger.get("berat_gabah", 0)

                if weight < 100:
                    logger.error(f"Berat gabah tidak valid: {weight} kg")
                    return

                process_id = self.prediction_trigger.get("process_id")
                kadar_air_target = self.prediction_trigger.get("kadar_air_target", 0)

                laravel_payload = {
                    "process_id": process_id,
                    "points": points,
                    "room_temperature": room_temp,
                    "avg_grain_temperature": avg_temp,
                    "avg_grain_moisture": avg_moist,
                    "predicted_drying_time": 0.0,
                    "weight": weight,
                    "timestamp": int(time.time())
                }

                # if avg_moist <= kadar_air_target:
                #     logger.info(f"Target kadar air tercapai: {avg_moist}% <= {kadar_air_target}% (ID: {process_id})")
                #     laravel_payload["predicted_drying_time"] = 0.0
                #     try:
                #         response = self.session.post(self.laravel_api_url, json=laravel_payload, timeout=15)
                #         response.raise_for_status()
                #         logger.info(f"Data terkirim ke Laravel (ID: {process_id}, Kadar Air Tercapai)")
                #         self.prediction_trigger = None  # Clear trigger after successful send
                #     except requests.RequestException as e:
                #         logger.error(f"Gagal kirim data ke Laravel: {e} (ID: {process_id})")
                #     return

                prediction_input = {
                    "GrainTemperature": avg_temp,
                    "GrainMoisture": avg_moist,
                    "RoomTemperature": room_temp,
                    "Weight": weight
                }

                predicted_time = self.model.predict(prediction_input)
                logger.info(f"Prediksi durasi pengeringan: {predicted_time:.2f} menit (ID: {process_id})")
                laravel_payload["predicted_drying_time"] = predicted_time

                try:
                    response = self.session.post(self.laravel_api_url, json=laravel_payload, timeout=15)
                    response.raise_for_status()
                    logger.info(f"Data terkirim ke Laravel (ID: {process_id}, Estimasi Durasi: {predicted_time:.2f} menit)")
                except requests.RequestException as e:
                    logger.error(f"Gagal kirim data ke Laravel: {e} (ID: {process_id})")

                # prediction_msg = json.dumps({"process_id": process_id, "DryingTime": predicted_time})
                # self.client.publish(self.output_topic, prediction_msg, qos=0)
                # logger.info(f"Prediksi diterbitkan ke {self.output_topic} (ID: {process_id})")

        except Exception as e:
            logger.error(f"Error memproses pesan sensor: {e} (ID: {self.prediction_trigger.get('process_id') if self.prediction_trigger else 'N/A'})")

    def start_mqtt(self):
        try:
            self.client.connect(self.broker, self.port, keepalive=60)
            self.client.loop_start()
            logger.info("Layanan MQTT dimulai")
        except Exception as e:
            logger.error(f"Gagal memulai MQTT: {e}")
            raise

    def stop(self):
        self.client.loop_stop()
        self.client.disconnect()
        logger.info("Layanan MQTT dihentikan")

@app.route('/predict', methods=['POST'])
def trigger_prediction():
    try:
        data = request.get_json()
        required_keys = ['process_id', 'grain_type_id', 'berat_gabah', 'kadar_air_target']
        if not all(key in data for key in required_keys):
            logger.error("Data prediksi tidak lengkap")
            return jsonify({"error": "Data tidak lengkap"}), 400

        if not isinstance(data['berat_gabah'], (int, float)) or data['berat_gabah'] < 100:
            logger.error(f"Berat gabah tidak valid: {data['berat_gabah']} kg")
            return jsonify({"error": "Berat gabah minimal 100 kg"}), 400

        if not isinstance(data['kadar_air_target'], (int, float)) or data['kadar_air_target'] < 0 or data['kadar_air_target'] > 100:
            logger.error(f"Target kadar air tidak valid: {data['kadar_air_target']}%")
            return jsonify({"error": "Target kadar air harus antara 0-100"}), 400

        with app.mqtt_service.lock:
            if app.mqtt_service.prediction_trigger:
                logger.warning(f"Prediksi sudah aktif (ID: {app.mqtt_service.prediction_trigger['process_id']})")
                return jsonify({"error": "Prediksi sudah aktif"}), 409
            app.mqtt_service.prediction_trigger = data
            logger.info(f"Mulai prediksi: ID {data['process_id']}, berat_gabah: {data['berat_gabah']} kg, target_kadar_air: {data['kadar_air_target']}%")

        return jsonify({"message": "Prediksi dimulai, menunggu data sensor"}), 200
    except Exception as e:
        logger.error(f"Gagal memulai prediksi: {e}")
        return jsonify({"error": "Gagal memulai prediksi"}), 500

@app.route('/stop-prediction', methods=['POST'])
def stop_prediction():
    try:
        data = request.get_json()
        if 'process_id' not in data:
            logger.error("ID proses tidak ada")
            return jsonify({"error": "ID proses tidak ada"}), 400

        with app.mqtt_service.lock:
            if not app.mqtt_service.prediction_trigger:
                logger.info("Tidak ada prediksi aktif untuk dihentikan")
                return jsonify({"message": "Tidak ada prediksi aktif"}), 200
            if app.mqtt_service.prediction_trigger['process_id'] != data['process_id']:
                logger.error(f"ID proses tidak cocok: {data['process_id']} != {app.mqtt_service.prediction_trigger['process_id']}")
                return jsonify({"error": "ID proses tidak cocok"}), 400
            process_id = app.mqtt_service.prediction_trigger['process_id']
            app.mqtt_service.prediction_trigger = None
            logger.info(f"Prediksi dihentikan: ID {process_id}")

        return jsonify({"message": "Prediksi dihentikan"}), 200
    except Exception as e:
        logger.error(f"Gagal menghentikan prediksi: {e}")
        return jsonify({"error": "Gagal menghentikan prediksi"}), 500

def run_flask(mqtt_service):
    app.mqtt_service = mqtt_service
    app.run(host='0.0.0.0', port=5000, debug=False)